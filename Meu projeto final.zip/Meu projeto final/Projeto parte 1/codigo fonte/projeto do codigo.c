/*
 Projeto: Agenda de Consultas Médicas
 Autor: [Íthalo Santos Cavalcante e Júlio César de Castro Oliveira Ximenes  ]
 Data de criação: [14/10/2025]
 Descrição: Estrutura inicial do projeto integrador.
*/

#include <stdio.h>

int main() {
    printf("Iniciando o Projeto Integrador - Agenda de Consultas Medicas...\\n");
    return 0;
}