# Agenda_de_Consultas_Medicas

## Objetivo geral
Sistema em C para agendamento, cancelamento e listagem de consultas médicas de forma simples e eficiente.

## Principais funcionalidades previstas
- Cadastrar pacientes
- Agendar consultas com data, hora, médico e especialidade
- Verificar disponibilidade de horário
- Cancelar consultas
- Salvar e carregar dados

## Autores
- [Íthalo Santos Cavalcante e Júlio César de Castro Oliveira Ximenes ]

## Etapas futuras
- Implementar structs Paciente e Consulta
- Modularizar o código (consultas.c / consultas.h)
- Criar persistência de dados em arquivo texto 

## Link para o repositorio
- https://github.com/ithalo2006/projeto-.git