#include <string.h>
#include "util.h"

void remover_quebra_linha(char *str) {
    for (int i = 0; str[i] != '\0'; i++) {
        if (str[i] == '\n') {
            str[i] = '\0';
            return;
        }
    }
}