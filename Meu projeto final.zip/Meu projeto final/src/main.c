#include <stdio.h>
#include "entrada.h"
#include "processamento.h"
#include "saida.h"

static void exibir_menu(void) {
    printf("\n===== AGENDA DE CONSULTAS =====\n");
    printf("1 - Cadastrar paciente\n");
    printf("2 - Listar pacientes\n");
    printf("3 - Agendar consulta\n");
    printf("4 - Listar consultas\n");
    printf("0 - Sair\n");
}

int main(void) {
    int opcao;

    do {
        exibir_menu();
        printf("Escolha: ");
        ler_inteiro_da_linha(&opcao);

        switch (opcao) {
            case 1: cadastrar_paciente(); break;
            case 2: listar_pacientes(); break;
            case 3: agendar_consulta(); break;
            case 4: listar_consultas(); break;
            case 0: printf("Encerrando...\n"); break;
            default: printf("Opção inválida.\n");
        }
    } while (opcao != 0);

    return 0;
}