#include <stdio.h>
#include "saida.h"
#include "processamento.h"

void listar_pacientes(void) {
    if (qtd_pacientes == 0) {
        printf("Nenhum paciente cadastrado.\n");
        return;
    }

    for (int i = 0; i < qtd_pacientes; i++) {
        printf("%d) %s - %d anos\n",
               i + 1,
               pacientes[i].nome,
               pacientes[i].idade);
    }
}

void listar_consultas(void) {
    if (qtd_consultas == 0) {
        printf("Nenhuma consulta agendada.\n");
        return;
    }

    for (int i = 0; i < qtd_consultas; i++) {
        printf("%d) %s | %s | %s\n",
               i + 1,
               pacientes[consultas[i].paciente_id - 1].nome,
               consultas[i].data,
               consultas[i].hora);
    }
}