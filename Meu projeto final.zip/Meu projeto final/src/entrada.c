#include <stdio.h>
#include "entrada.h"

int ler_inteiro_da_linha(int *out) {
    if (scanf("%d", out) != 1)
        return 0;
    getchar(); 
    return 1;
}