/*
 Projeto: Agenda de consultas 
 Autor: Íthalo Santos Cavalcante e Júlio César de Castro Ximenes
 Data de criação: 12/11/2025
 Descrição: Como prometido na parte 1, o nosso projeto vem com a implementação do agendamento
  Funcionalidades:
  - Cadastrar pacientes (nome, idade)
  - Listar pacientes
  - Agendar consultas
  - Listar consultas
  - Sair
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_PACIENTES 50
#define NOME_TAM 80

#define MAX_CONSULTAS 200
#define DATA_TAM 11   // "YYYY-MM-DD" + '\0'
#define HORA_TAM 6    // "HH:MM" + '\0'

char nomes[MAX_PACIENTES][NOME_TAM];
int idades[MAX_PACIENTES];
int qtd = 0;

/* Consultas simples em arrays paralelos */
int consultas_paciente[MAX_CONSULTAS];                 // ID do paciente (1..qtd)
char consultas_data[MAX_CONSULTAS][DATA_TAM];          // "YYYY-MM-DD"
char consultas_hora[MAX_CONSULTAS][HORA_TAM];          // "HH:MM"
int qtd_consultas = 0;

/*
 Função simples para ler um número inteiro.
*/
int ler_inteiro_da_linha(int *out) {
    if (scanf("%d", out) != 1) {
        return 0; 
    }
    getchar(); 
    return 1;
}

void cadastrar_paciente() {
    if (qtd >= MAX_PACIENTES) {
        printf("Limite de pacientes atingido (%d).\n", MAX_PACIENTES);
        return;
    }

    printf("\nCadastro de paciente #%d\n", qtd + 1);
    printf("Nome: ");

    fgets(nomes[qtd], NOME_TAM, stdin);

    
    for (int i = 0; nomes[qtd][i] != '\0'; i++) {
        if (nomes[qtd][i] == '\n') {
            nomes[qtd][i] = '\0';
            break;
        }
    }

    printf("Idade: ");
    int idade;

    if (!ler_inteiro_da_linha(&idade)) {
        printf("Idade inválida. Cancelando cadastro.\n");
        return;
    }

    if (idade < 0 || idade > 130) {
        printf("Idade fora do intervalo.\n");
        return;
    }

    idades[qtd] = idade;
    qtd++;

    printf("Paciente cadastrado com sucesso!\n");
}

void listar_pacientes() {
    if (qtd == 0) {
        printf("Nenhum paciente cadastrado.\n");
        return;
    }

    printf("\n--- Lista de Pacientes (%d) ---\n", qtd);
    for (int i = 0; i < qtd; i++) {
        printf("%d) Nome: %s | Idade: %d\n",
               i + 1, nomes[i], idades[i]);
    }
}

/* Verifica se já existe consulta para esse paciente na mesma data/hora */
int consulta_existe(int paciente_id, const char *data, const char *hora) {
    for (int i = 0; i < qtd_consultas; i++) {
        if (consultas_paciente[i] == paciente_id &&
            strcmp(consultas_data[i], data) == 0 &&
            strcmp(consultas_hora[i], hora) == 0) {
            return 1;
        }
    }
    return 0;
}

void agendar_consulta() {
    if (qtd_consultas >= MAX_CONSULTAS) {
        printf("Limite de consultas atingido (%d).\n", MAX_CONSULTAS);
        return;
    }
    if (qtd == 0) {
        printf("Nenhum paciente cadastrado. Cadastre um paciente antes de agendar.\n");
        return;
    }

    printf("\n--- Agendar Consulta ---\n");
    listar_pacientes();
    printf("Escolha o ID do paciente para agendar (1 - %d): ", qtd);

    int pid;
    if (!ler_inteiro_da_linha(&pid)) {
        printf("ID inválido.\n");
        return;
    }
    if (pid < 1 || pid > qtd) {
        printf("ID fora do intervalo.\n");
        return;
    }

    // Ler data
    printf("Data (YYYY-MM-DD): ");
    if (!fgets(consultas_data[qtd_consultas], DATA_TAM, stdin)) {
        printf("Erro lendo data.\n");
        return;
    }
    // retirar \n
    for (int i = 0; consultas_data[qtd_consultas][i] != '\0'; i++) {
        if (consultas_data[qtd_consultas][i] == '\n') {
            consultas_data[qtd_consultas][i] = '\0';
            break;
        }
    }

    // Ler hora
    printf("Hora (HH:MM): ");
    if (!fgets(consultas_hora[qtd_consultas], HORA_TAM, stdin)) {
        printf("Erro lendo hora.\n");
        return;
    }
    // retirar \n
    for (int i = 0; consultas_hora[qtd_consultas][i] != '\0'; i++) {
        if (consultas_hora[qtd_consultas][i] == '\n') {
            consultas_hora[qtd_consultas][i] = '\0';
            break;
        }
    }

    // Verifica duplicata simples (mesmo paciente, mesma data e hora)
    if (consulta_existe(pid, consultas_data[qtd_consultas], consultas_hora[qtd_consultas])) {
        printf("Já existe uma consulta para esse paciente na mesma data e hora.\n");
        return;
    }

    // Gravar a consulta
    consultas_paciente[qtd_consultas] = pid;
    qtd_consultas++;
    printf("Consulta agendada com sucesso para %s às %s (paciente ID %d).\n",
           consultas_data[qtd_consultas-1],
           consultas_hora[qtd_consultas-1],
           pid);
}

void listar_consultas() {
    if (qtd_consultas == 0) {
        printf("Nenhuma consulta agendada.\n");
        return;
    }

    printf("\n--- Lista de Consultas (%d) ---\n", qtd_consultas);
    for (int i = 0; i < qtd_consultas; i++) {
        int pid = consultas_paciente[i];
        printf("%d) Paciente ID:%d Nome:%s | Data:%s Hora:%s\n",
               i + 1,
               pid,
               (pid >= 1 && pid <= qtd) ? nomes[pid-1] : "Unknown",
               consultas_data[i],
               consultas_hora[i]);
    }
}

int menu() {
    printf("\n=== AGENDA SIMPLES ===\n");
    printf("1 - Cadastrar paciente\n");
    printf("2 - Listar pacientes\n");
    printf("3 - Agendar consulta\n");
    printf("4 - Listar consultas\n");
    printf("0 - Sair\n");
    printf("Escolha: ");

    int op;
    if (!ler_inteiro_da_linha(&op)) {
        return -1; 
    }
    return op;
}

int main(void) {
    int rodando = 1;

    while (rodando) {
        int op = menu();

        switch (op) {
            case 1:
                cadastrar_paciente();
                break;

            case 2:
                listar_pacientes();
                break;

            case 3:
                agendar_consulta();
                break;

            case 4:
                listar_consultas();
                break;

            case 0:
                printf("Saindo...\n");
                rodando = 0;
                break;

            default:
                printf("Opção inválida. Tente novamente.\n");
        }
    }

    return 0;
}