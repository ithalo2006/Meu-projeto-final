#ifndef ENTRADA_H
#define ENTRADA_H

int ler_inteiro_da_linha(int *out);

#endif