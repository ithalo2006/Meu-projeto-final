#ifndef TIPOS_H
#define TIPOS_H

#define MAX_PACIENTES 50
#define MAX_CONSULTAS 200
#define NOME_TAM 80
#define DATA_TAM 11
#define HORA_TAM 6


typedef struct {
    char nome[NOME_TAM];
    int idade;
} Paciente;


typedef struct {
    int paciente_id;
    char data[DATA_TAM];
    char hora[HORA_TAM];
} Consulta;

#endif