#ifndef PROCESSAMENTO_H
#define PROCESSAMENTO_H

#include "tipos.h"

extern Paciente pacientes[MAX_PACIENTES];
extern Consulta consultas[MAX_CONSULTAS];
extern int qtd_pacientes;
extern int qtd_consultas;

void cadastrar_paciente(void);
void agendar_consulta(void);

#endif