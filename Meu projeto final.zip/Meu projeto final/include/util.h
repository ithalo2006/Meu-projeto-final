#ifndef UTIL_H
#define UTIL_H

void remover_quebra_linha(char *str);

#endif