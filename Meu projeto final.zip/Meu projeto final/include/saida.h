#ifndef SAIDA_H
#define SAIDA_H


void listar_pacientes(void);
void listar_consultas(void);

#endif